//
//  HowToUseVC.h
//  RallyRoadbookReader
//
//  Created by NC2-25 on 02/10/18.
//  Copyright © 2018 C205. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HowToUseVC : BaseVC

@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;


@end
