//
//  NavigationVC.h
//  RallyRoadbookReader
//
//  Created by Eliot Gravett on 2018/12/23.
//  Copyright © 2018 C205. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NavigationVC : UINavigationController

@end

NS_ASSUME_NONNULL_END
