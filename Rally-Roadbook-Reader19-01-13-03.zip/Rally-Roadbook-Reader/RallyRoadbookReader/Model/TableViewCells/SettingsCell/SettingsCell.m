//
//  SettingsCell.m
//  RallyRoadbookReader
//
//  Created by C205 on 14/09/18.
//  Copyright © 2018 C205. All rights reserved.
//

#import "SettingsCell.h"

@implementation SettingsCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
