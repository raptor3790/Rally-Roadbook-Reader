//
//  RoadbooksCell.m
//  RallyRoadbookReader
//
//  Created by C205 on 27/09/18.
//  Copyright © 2018 C205. All rights reserved.
//

#import "RoadbooksCell.h"

@implementation RoadbooksCell

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

@end
