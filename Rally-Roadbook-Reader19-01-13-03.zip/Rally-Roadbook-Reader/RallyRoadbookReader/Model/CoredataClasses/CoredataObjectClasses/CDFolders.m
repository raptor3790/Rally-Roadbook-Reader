#import "CDFolders.h"

@interface CDFolders ()

// Private interface goes here.

@end

@implementation CDFolders

// Custom logic goes here.

@end
