#import "_CDFolders.h"

@interface CDFolders : _CDFolders
// Custom logic goes here.
@end
