#import "CDRoute.h"

@interface CDRoute ()

// Private interface goes here.

@end

@implementation CDRoute

// Custom logic goes here.

@end
