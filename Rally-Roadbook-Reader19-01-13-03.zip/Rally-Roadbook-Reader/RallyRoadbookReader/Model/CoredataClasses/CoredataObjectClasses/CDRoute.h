#import "_CDRoute.h"

@interface CDRoute : _CDRoute
// Custom logic goes here.
@end
